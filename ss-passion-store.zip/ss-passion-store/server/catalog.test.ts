import { describe, expect, it } from "vitest";
import { getProduct, money, products } from "../client/src/data/products";

describe("SS PASSION product catalog", () => {
  it("contains structured products with variant-ready fields", () => {
    expect(products.length).toBeGreaterThanOrEqual(10);
    for (const product of products) {
      expect(product.id).toBeTruthy();
      expect(product.slug).toBeTruthy();
      expect(product.name).toBeTruthy();
      expect(product.price).toBeGreaterThan(0);
      expect(product.images.length).toBeGreaterThanOrEqual(3);
      expect(product.colors.length).toBeGreaterThan(1);
      expect(product.sizes.length).toBeGreaterThan(2);
      expect(["Women", "Men"]).toContain(product.gender);
    }
  });

  it("resolves products by slug and formats prices consistently", () => {
    expect(getProduct("signature-oversized-tee")?.name).toBe("Signature Oversized Tee");
    expect(getProduct("missing-product")?.id).toBe(products[0]?.id);
    expect(money(49)).toBe("$49.00");
  });
});
