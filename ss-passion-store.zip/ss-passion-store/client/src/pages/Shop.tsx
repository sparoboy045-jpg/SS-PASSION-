import { useMemo, useState } from "react";
import { Link } from "wouter";
import { ArrowRight, X } from "lucide-react";
import { products } from "@/data/products";
import { FilterBar, FilterPanel, ProductGrid, SiteFooter, useStore } from "@/components/Storefront";

export default function Shop() {
  const params = new URLSearchParams(window.location.search);
  const [filters, setFilters] = useState({ gender: params.get("gender") ?? "", category: params.get("category") ?? "", color: params.get("color") ?? "" });
  const [sort, setSort] = useState(params.get("sort") === "new" ? "newest" : "recommended");
  const [panelOpen, setPanelOpen] = useState(false);
  const filtered = useMemo(() => {
    const result = products.filter((product) => (!filters.gender || product.gender === filters.gender) && (!filters.category || product.category === filters.category) && (!filters.color || product.colors.includes(filters.color)));
    return [...result].sort((a, b) => sort === "low" ? a.price - b.price : sort === "high" ? b.price - a.price : sort === "newest" ? Number(Boolean(b.newArrival)) - Number(Boolean(a.newArrival)) : sort === "best" ? Number(Boolean(b.bestSeller)) - Number(Boolean(a.bestSeller)) : Number(Boolean(b.featured)) - Number(Boolean(a.featured)));
  }, [filters, sort]);
  return <div className="page-shell"><main className="shop-page"><div className="page-intro"><div><div className="label-eyebrow">The full edit</div><h1>Shop all.</h1></div><p>Modern essentials for the way you live. Explore the complete SS PASSION collection.</p></div><FilterBar count={filtered.length} onFilterClick={() => setPanelOpen(true)} sort={sort} setSort={setSort} />{(filters.gender || filters.category || filters.color) && <div className="active-filters">{Object.entries(filters).filter(([, value]) => value).map(([key, value]) => <button key={key} onClick={() => setFilters({ ...filters, [key]: "" })}>{value} <X size={12} /></button>)}<button onClick={() => setFilters({ gender: "", category: "", color: "" })}>Clear all</button></div>}{filtered.length ? <ProductGrid items={filtered} /> : <div className="empty-shop"><h2>No pieces found.</h2><p>Try adjusting your filters.</p><button className="button button-dark" onClick={() => setFilters({ gender: "", category: "", color: "" })}>Clear filters <ArrowRight size={15} /></button></div>}{panelOpen && <div className="overlay" onClick={() => setPanelOpen(false)}><div onClick={(e) => e.stopPropagation()}><FilterPanel filters={filters} setFilters={setFilters} close={() => setPanelOpen(false)} /></div></div>}</main><SiteFooter /></div>;
}
