import { Link } from "wouter";
import { ArrowRight, Heart, UserRound } from "lucide-react";
import { ProductGrid, SiteFooter, useStore } from "@/components/Storefront";
import { products } from "@/data/products";

export function Wishlist() {
  const { wishlist } = useStore(); const saved = products.filter((product) => wishlist.includes(product.id));
  return <div className="page-shell"><main className="shop-page"><div className="page-intro"><div><div className="label-eyebrow">Saved for later</div><h1>Wishlist.</h1></div><p>Your considered edit, kept in one place.</p></div>{saved.length ? <ProductGrid items={saved} /> : <div className="empty-shop"><Heart size={22} strokeWidth={1.5} /><h2>Your wishlist is waiting.</h2><p>Save the pieces you love as you explore the collection.</p><Link href="/shop" className="button button-dark">Explore the collection <ArrowRight size={15} /></Link></div>}</main><SiteFooter /></div>;
}

export default function Account() {
  return <div className="page-shell"><main className="content-page"><div className="page-intro"><div><div className="label-eyebrow">Your SS PASSION</div><h1>Account.</h1></div><p>Sign in to keep your wishlist, orders and addresses together.</p></div><div className="account-card"><UserRound size={24} strokeWidth={1.4} /><h2>Account access is ready to connect.</h2><p>Manus OAuth is configured in the project foundation. Connect the account portal when your production identity flow is ready — no placeholder credentials or fake authentication are used here.</p><button className="button button-dark" onClick={() => window.alert("Account sign-in is ready to connect to the configured OAuth flow.")}>Continue to sign in <ArrowRight size={15} /></button></div></main><SiteFooter /></div>;
}
