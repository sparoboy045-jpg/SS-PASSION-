import { Link } from "wouter";
import { ArrowRight } from "lucide-react";
import { products } from "@/data/products";
import { Newsletter, ProductGrid, SectionHeader, SiteFooter } from "@/components/Storefront";

const hero = "/manus-storage/hero_580e5fa9.jpg";
const women = "/manus-storage/women_fff0630c.jpg";
const campaign = "/manus-storage/campaign_0043a22f.jpg";
const store = "/manus-storage/store_7b3d730d.jpg";

export default function Home() {
  const newArrivals = products.filter((product) => product.newArrival);
  const bestSellers = products.filter((product) => product.bestSeller);
  return <div className="page-shell"><main className="home-main">
    <section className="hero"><div className="hero-copy"><div className="label-eyebrow">SS PASSION / New season</div><h1>The new essentials.</h1><p>Modern pieces designed for everyday confidence — wherever the day takes you.</p><div className="hero-actions"><Link href="/shop?gender=Women" className="button button-dark">Shop women <ArrowRight size={15} strokeWidth={1.5} /></Link><Link href="/shop?gender=Men" className="text-link">Shop men <ArrowRight size={14} strokeWidth={1.5} /></Link></div></div><div className="hero-image"><img src={hero} alt="Woman in neutral SS PASSION inspired tailoring" /><span className="hero-caption">Collection 01 — 2026</span></div></section>
    <section className="statement"><div className="label-eyebrow">The SS PASSION point of view</div><h2>Modern. Timeless. Essential.</h2><p>SS PASSION creates refined everyday clothing designed to move effortlessly between moments, seasons and places.</p><Link href="/about" className="text-link">Discover SS PASSION <ArrowRight size={14} strokeWidth={1.5} /></Link></section>
    <section className="section"><SectionHeader eyebrow="The latest edit" title="New arrivals" link="Shop all" /><ProductGrid items={newArrivals} limit={4} /></section>
    <section className="section" style={{ paddingTop: 0 }}><div className="category-editorial"><Link href="/shop?gender=Women" className="editorial-block"><img src={women} alt="Woman in a softly tailored neutral look" /><div className="editorial-block-content"><h3>Women</h3><span>Shop women →</span></div></Link><Link href="/shop?gender=Men" className="editorial-block"><img src={store} alt="Minimal fashion store interior" /><div className="editorial-block-content"><h3>Men</h3><span>Shop men →</span></div></Link></div></section>
    <section className="section"><div className="collection-feature"><div className="collection-copy"><div className="label-eyebrow">The collection</div><h2>The essentials.</h2><p>Timeless pieces designed to become part of your everyday wardrobe — considered, versatile and easy to live in.</p><Link href="/shop" className="text-link">Explore collection <ArrowRight size={14} strokeWidth={1.5} /></Link></div><div className="collection-image"><img src={store} alt="SS PASSION collection in a minimal interior" /></div></div></section>
    <section className="section" style={{ paddingTop: 0 }}><div className="campaign"><img src={campaign} alt="Editorial campaign in warm natural light" /><div className="campaign-copy"><div className="label-eyebrow">SS PASSION / New season</div><h2>Designed for now.<br />Made to last.</h2><Link href="/shop" className="text-link">Discover the collection <ArrowRight size={14} strokeWidth={1.5} /></Link></div></div></section>
    <section className="section"><SectionHeader eyebrow="What people are wearing" title="Most wanted" link="View all" /><ProductGrid items={bestSellers} limit={4} /></section>
    <section className="philosophy"><div><div className="label-eyebrow">Our philosophy</div><h2>Less, but better.</h2></div><div className="philosophy-copy"><p>We focus on the things that make clothing feel good to wear: timeless design, modern proportions, considered materials and the confidence of an uncomplicated wardrobe.</p><Link href="/about" className="text-link">Our approach <ArrowRight size={14} strokeWidth={1.5} /></Link><div className="philosophy-list"><div><span>01</span> Timeless design</div><div><span>02</span> Everyday wearability</div><div><span>03</span> Modern proportions</div></div></div></section>
    <section className="section"><SectionHeader eyebrow="The journal" title="Stories to keep." link="Read all stories" href="/journal" /><div className="journal-grid"><Link className="journal-card" href="/journal"><img src={campaign} alt="Woman in warm light" /><div className="label-eyebrow">Perspective</div><h3>The art of everyday dressing</h3><p>On building a wardrobe that makes getting dressed feel intuitive.</p></Link><Link className="journal-card" href="/journal"><img src={women} alt="Minimal fashion portrait" /><div className="label-eyebrow">Wardrobe</div><h3>Building a timeless wardrobe</h3><p>The pieces that carry more than one season.</p></Link><Link className="journal-card" href="/journal"><img src={store} alt="Minimal interior" /><div className="label-eyebrow">Materials</div><h3>Fabric & craft</h3><p>A closer look at what makes an essential.</p></Link></div></section>
    <Newsletter />
  </main><SiteFooter /></div>;
}
