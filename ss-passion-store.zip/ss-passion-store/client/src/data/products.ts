export type Product = {
  id: string;
  slug: string;
  name: string;
  description: string;
  category: string;
  gender: "Women" | "Men";
  price: number;
  images: string[];
  colors: string[];
  sizes: string[];
  material: string;
  fit: string;
  collection: string;
  tags: string[];
  featured?: boolean;
  newArrival?: boolean;
  bestSeller?: boolean;
};

const hero = "/manus-storage/hero_580e5fa9.jpg";
const women = "/manus-storage/women_fff0630c.jpg";
const campaign = "/manus-storage/campaign_0043a22f.jpg";
const store = "/manus-storage/store_7b3d730d.jpg";

export const products: Product[] = [
  {
    id: "p-001", slug: "signature-oversized-tee", name: "Signature Oversized Tee",
    description: "A considered essential with a relaxed silhouette and a soft, structured handfeel.", category: "T-Shirts", gender: "Men", price: 49,
    images: [hero, store, women], colors: ["Ivory", "Black", "Stone"], sizes: ["S", "M", "L", "XL", "XXL"],
    material: "100% combed cotton", fit: "Relaxed, oversized fit", collection: "The Essentials", tags: ["everyday", "cotton", "core"], newArrival: true, bestSeller: true, featured: true,
  },
  {
    id: "p-002", slug: "premium-relaxed-shirt", name: "Premium Relaxed Shirt",
    description: "An easy, polished shirt cut with a little room to move between work and weekend.", category: "Shirts", gender: "Men", price: 75,
    images: [store, hero, campaign], colors: ["Ivory", "Stone", "Taupe"], sizes: ["S", "M", "L", "XL"],
    material: "Cotton poplin", fit: "Relaxed fit", collection: "The Essentials", tags: ["shirt", "everyday"], newArrival: true, featured: true,
  },
  {
    id: "p-003", slug: "essential-polo", name: "Essential Polo",
    description: "A clean, modern polo with a softly structured collar and a fine-gauge finish.", category: "Polos", gender: "Men", price: 65,
    images: [campaign, hero, store], colors: ["Black", "Ivory", "Navy"], sizes: ["S", "M", "L", "XL"],
    material: "Mercerised cotton", fit: "True to size", collection: "Weekend Edit", tags: ["polo", "weekend"], bestSeller: true,
  },
  {
    id: "p-004", slug: "tailored-relaxed-trousers", name: "Tailored Relaxed Trousers",
    description: "Modern proportions meet everyday ease in a pair designed to anchor your wardrobe.", category: "Trousers", gender: "Men", price: 89,
    images: [women, campaign, hero], colors: ["Stone", "Black", "Taupe"], sizes: ["S", "M", "L", "XL"],
    material: "Viscose blend", fit: "Relaxed straight leg", collection: "Modern Tailoring", tags: ["tailoring", "trouser"], featured: true,
  },
  {
    id: "p-005", slug: "signature-blazer", name: "Signature Blazer", description: "An unlined blazer with a quiet confidence and a softly defined shoulder.", category: "Blazers", gender: "Men", price: 149,
    images: [campaign, store, hero], colors: ["Charcoal", "Stone"], sizes: ["S", "M", "L", "XL"], material: "Wool blend", fit: "Relaxed tailored fit", collection: "Modern Tailoring", tags: ["blazer", "tailoring"], bestSeller: true,
  },
  {
    id: "p-006", slug: "minimal-overshirt", name: "Minimal Overshirt", description: "A versatile layer for transitional days, finished with considered utility pockets.", category: "Overshirts", gender: "Men", price: 85,
    images: [store, campaign, women], colors: ["Stone", "Olive", "Black"], sizes: ["S", "M", "L", "XL"], material: "Brushed cotton twill", fit: "Boxy relaxed fit", collection: "New Season", tags: ["layering", "utility"], newArrival: true,
  },
  {
    id: "p-007", slug: "essential-relaxed-tee", name: "Essential Relaxed Tee", description: "A softly sculpted tee with a subtly dropped shoulder and clean finish.", category: "T-Shirts", gender: "Women", price: 45,
    images: [women, hero, store], colors: ["Ivory", "Black", "Grey"], sizes: ["XS", "S", "M", "L", "XL"], material: "Supima cotton", fit: "Relaxed fit", collection: "The Essentials", tags: ["everyday", "cotton"], newArrival: true, featured: true,
  },
  {
    id: "p-008", slug: "signature-ribbed-top", name: "Signature Ribbed Top", description: "A refined rib-knit layer made to sit close without feeling restrictive.", category: "Knitwear", gender: "Women", price: 59,
    images: [hero, women, campaign], colors: ["Cream", "Black", "Taupe"], sizes: ["XS", "S", "M", "L"], material: "Viscose rib knit", fit: "Close fit", collection: "Weekend Edit", tags: ["ribbed", "layering"], bestSeller: true,
  },
  {
    id: "p-009", slug: "tailored-wide-leg-trousers", name: "Tailored Wide-Leg Trousers", description: "Fluid tailoring with a clean line and a generous, effortless leg.", category: "Trousers", gender: "Women", price: 95,
    images: [women, campaign, store], colors: ["Stone", "Black", "Navy"], sizes: ["XS", "S", "M", "L", "XL"], material: "Viscose crepe", fit: "High-rise wide leg", collection: "Modern Tailoring", tags: ["tailoring", "wide leg"], featured: true,
  },
  {
    id: "p-010", slug: "minimal-blazer", name: "Minimal Blazer", description: "A soft-shouldered blazer that brings an editorial finish to everyday dressing.", category: "Blazers", gender: "Women", price: 139,
    images: [campaign, women, store], colors: ["Charcoal", "Stone"], sizes: ["XS", "S", "M", "L"], material: "Wool blend", fit: "Relaxed tailored fit", collection: "Modern Tailoring", tags: ["blazer", "tailoring"], bestSeller: true,
  },
  {
    id: "p-011", slug: "relaxed-linen-shirt", name: "Relaxed Linen Shirt", description: "A warm-weather staple with a dry touch and an easy, generous cut.", category: "Shirts", gender: "Women", price: 79,
    images: [store, women, hero], colors: ["Ivory", "Stone", "Taupe"], sizes: ["XS", "S", "M", "L", "XL"], material: "European linen", fit: "Relaxed fit", collection: "New Season", tags: ["linen", "summer"], newArrival: true,
  },
  {
    id: "p-012", slug: "essential-midi-dress", name: "Essential Midi Dress", description: "A clean-lined midi dress built around movement, proportion and ease.", category: "Dresses", gender: "Women", price: 109,
    images: [hero, campaign, women], colors: ["Black", "Ivory", "Stone"], sizes: ["XS", "S", "M", "L"], material: "Tencel blend", fit: "Relaxed column shape", collection: "The Essentials", tags: ["dress", "occasion"], featured: true,
  },
];

export const getProduct = (slug?: string) => products.find((product) => product.slug === slug) ?? products[0];
export const money = (value: number) => `$${value.toFixed(2)}`;
