import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { Link, useLocation } from "wouter";
import { ArrowRight, Check, ChevronDown, ChevronLeft, ChevronRight, Heart, Menu, Search, ShoppingBag, SlidersHorizontal, X } from "lucide-react";
import { products, money, type Product } from "@/data/products";

type CartItem = { product: Product; color: string; size: string; quantity: number };
type StoreContextValue = {
  bag: CartItem[]; wishlist: string[]; addToBag: (product: Product, color?: string, size?: string, quantity?: number) => void;
  updateQuantity: (id: string, delta: number) => void; removeFromBag: (id: string) => void; toggleWishlist: (id: string) => void;
  searchOpen: boolean; setSearchOpen: (value: boolean) => void; cartOpen: boolean; setCartOpen: (value: boolean) => void;
  notice: string | null; setNotice: (value: string | null) => void;
};
const StoreContext = createContext<StoreContextValue | null>(null);

export function StorefrontProvider({ children }: { children: ReactNode }) {
  const [bag, setBag] = useState<CartItem[]>(() => { try { return JSON.parse(localStorage.getItem("ss-passion-bag") || "[]"); } catch { return []; } });
  const [wishlist, setWishlist] = useState<string[]>(() => { try { return JSON.parse(localStorage.getItem("ss-passion-wishlist") || "[]"); } catch { return []; } });
  const [searchOpen, setSearchOpen] = useState(false); const [cartOpen, setCartOpen] = useState(false); const [notice, setNotice] = useState<string | null>(null);
  useEffect(() => { localStorage.setItem("ss-passion-bag", JSON.stringify(bag)); }, [bag]);
  useEffect(() => { localStorage.setItem("ss-passion-wishlist", JSON.stringify(wishlist)); }, [wishlist]);
  useEffect(() => { if (!notice) return; const t = window.setTimeout(() => setNotice(null), 2600); return () => window.clearTimeout(t); }, [notice]);
  const addToBag = (product: Product, color = product.colors[0], size = product.sizes[Math.min(1, product.sizes.length - 1)], quantity = 1) => {
    setBag((current) => { const existing = current.find((item) => item.product.id === product.id && item.color === color && item.size === size); if (existing) return current.map((item) => item === existing ? { ...item, quantity: item.quantity + quantity } : item); return [...current, { product, color, size, quantity }]; });
    setNotice("Added to your bag"); setCartOpen(true);
  };
  const updateQuantity = (id: string, delta: number) => setBag((current) => current.map((item) => item.product.id === id ? { ...item, quantity: Math.max(1, item.quantity + delta) } : item));
  const removeFromBag = (id: string) => setBag((current) => current.filter((item) => item.product.id !== id));
  const toggleWishlist = (id: string) => setWishlist((current) => current.includes(id) ? current.filter((item) => item !== id) : [...current, id]);
  return <StoreContext.Provider value={{ bag, wishlist, addToBag, updateQuantity, removeFromBag, toggleWishlist, searchOpen, setSearchOpen, cartOpen, setCartOpen, notice, setNotice }}>{children}<CartDrawer /><SearchOverlay />{notice && <div className="fixed bottom-6 left-1/2 z-[80] -translate-x-1/2 bg-charcoal px-5 py-3 text-[11px] font-semibold uppercase tracking-[0.18em] text-ivory shadow-lg">{notice}</div>}</StoreContext.Provider>;
}
export const useStore = () => { const value = useContext(StoreContext); if (!value) throw new Error("useStore must be used inside StorefrontProvider"); return value; };

export function SiteHeader() {
  const [location] = useLocation(); const { bag, wishlist, setSearchOpen, setCartOpen } = useStore(); const [menuOpen, setMenuOpen] = useState(false);
  const nav = [{ label: "New In", href: "/shop?sort=new" }, { label: "Women", href: "/shop?gender=Women" }, { label: "Men", href: "/shop?gender=Men" }, { label: "Collections", href: "/shop" }, { label: "Journal", href: "/journal" }];
  return <>
    <div className="announcement">Worldwide shipping available <span>·</span> complimentary delivery over $150</div>
    <header className="site-header">
      <div className="header-inner">
        <button className="mobile-menu-button" aria-label="Open menu" onClick={() => setMenuOpen(true)}><Menu size={19} strokeWidth={1.5} /></button>
        <Link href="/" className="brand-mark"><span className="monogram">SS</span><span className="wordmark">PASSION</span></Link>
        <nav className="desktop-nav">{nav.map((item) => <Link key={item.label} href={item.href} className={location.startsWith(item.href.split("?")[0]) ? "active" : ""}>{item.label}</Link>)}</nav>
        <div className="header-actions">
          <button aria-label="Search" onClick={() => setSearchOpen(true)}><Search size={17} strokeWidth={1.5} /><span className="action-label">Search</span></button>
          <Link href="/account" aria-label="Account" className="account-link"><span className="action-label">Account</span></Link>
          <Link href="/wishlist" aria-label="Wishlist" className="icon-with-count"><Heart size={17} strokeWidth={1.5} fill={wishlist.length ? "currentColor" : "none"} /><span className="action-label">Wishlist</span>{wishlist.length > 0 && <b>{wishlist.length}</b>}</Link>
          <button aria-label="Bag" className="icon-with-count" onClick={() => setCartOpen(true)}><ShoppingBag size={17} strokeWidth={1.5} /><span className="action-label">Bag</span>{bag.length > 0 && <b>{bag.reduce((sum, item) => sum + item.quantity, 0)}</b>}</button>
        </div>
      </div>
    </header>
    {menuOpen && <div className="mobile-menu"><div className="mobile-menu-top"><span className="label-eyebrow">Menu</span><button onClick={() => setMenuOpen(false)} aria-label="Close menu"><X size={22} strokeWidth={1.5} /></button></div><nav>{[...nav, { label: "About", href: "/about" }, { label: "Contact", href: "/contact" }, { label: "Account", href: "/account" }, { label: "Help", href: "/contact" }].map((item) => <Link key={item.label} href={item.href} onClick={() => setMenuOpen(false)}>{item.label}</Link>)}</nav><div className="mobile-menu-foot">SS PASSION<br /><span>Modern clothing for everyday confidence.</span></div></div>}
  </>;
}

export function ProductCard({ product, priority = false }: { product: Product; priority?: boolean }) {
  const { wishlist, toggleWishlist, addToBag } = useStore();
  const wished = wishlist.includes(product.id);
  return <article className="product-card">
    <Link href={`/product/${product.slug}`} className="product-image-wrap">
      <img src={product.images[0]} alt={product.name} loading={priority ? "eager" : "lazy"} className="product-image primary" />
      <img src={product.images[1]} alt={`${product.name} alternate view`} loading="lazy" className="product-image alternate" />
      {product.newArrival && <span className="image-tag">New in</span>}
      <button className={`wishlist-button ${wished ? "is-wished" : ""}`} aria-label={wished ? "Remove from wishlist" : "Add to wishlist"} onClick={(event) => { event.preventDefault(); toggleWishlist(product.id); }}><Heart size={17} strokeWidth={1.5} fill={wished ? "currentColor" : "none"} /></button>
      <button className="quick-add" onClick={(event) => { event.preventDefault(); addToBag(product); }}>Quick add <ArrowRight size={14} strokeWidth={1.5} /></button>
    </Link>
    <div className="product-meta"><div><Link href={`/product/${product.slug}`} className="product-name">{product.name}</Link><div className="product-colors">{product.colors.slice(0, 3).map((color) => <span key={color} className={`swatch swatch-${color.toLowerCase()}`} title={color} />)}<span>{product.colors.length} colours</span></div></div><span className="product-price">{money(product.price)}</span></div>
  </article>;
}

export function ProductGrid({ items, limit }: { items: Product[]; limit?: number }) { return <div className="product-grid">{items.slice(0, limit ?? items.length).map((product, index) => <ProductCard key={product.id} product={product} priority={index < 2} />)}</div>; }
export function SectionHeader({ eyebrow, title, link, href = "/shop" }: { eyebrow?: string; title: string; link?: string; href?: string }) { return <div className="section-header"><div>{eyebrow && <div className="label-eyebrow">{eyebrow}</div>}<h2>{title}</h2></div>{link && <Link href={href} className="text-link">{link} <ArrowRight size={14} strokeWidth={1.5} /></Link>}</div>; }

function CartDrawer() {
  const { bag, cartOpen, setCartOpen, updateQuantity, removeFromBag } = useStore(); const subtotal = bag.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  return cartOpen ? <div className="overlay" onClick={() => setCartOpen(false)}><aside className="cart-drawer" onClick={(e) => e.stopPropagation()}><div className="drawer-head"><div><div className="label-eyebrow">Your bag</div><h3>{bag.length ? `${bag.length} item${bag.length > 1 ? "s" : ""}` : "Your bag is empty"}</h3></div><button onClick={() => setCartOpen(false)} aria-label="Close bag"><X size={21} strokeWidth={1.5} /></button></div>{bag.length ? <><div className="drawer-items">{bag.map((item) => <div className="drawer-item" key={`${item.product.id}-${item.color}-${item.size}`}><img src={item.product.images[0]} alt={item.product.name} /><div className="drawer-item-info"><div className="drawer-item-top"><Link href={`/product/${item.product.slug}`} onClick={() => setCartOpen(false)}>{item.product.name}</Link><button onClick={() => removeFromBag(item.product.id)} aria-label="Remove item"><X size={15} /></button></div><p>{item.color} · {item.size}</p><div className="drawer-item-bottom"><div className="qty-control"><button onClick={() => updateQuantity(item.product.id, -1)}>-</button><span>{item.quantity}</span><button onClick={() => updateQuantity(item.product.id, 1)}>+</button></div><strong>{money(item.product.price * item.quantity)}</strong></div></div></div>)}</div><div className="drawer-summary"><div><span>Subtotal</span><strong>{money(subtotal)}</strong></div><p>Shipping and taxes calculated at checkout.</p><button className="button button-dark" onClick={() => window.alert("Checkout integration ready. Connect your payment provider to continue.")}>Checkout <ArrowRight size={15} strokeWidth={1.5} /></button><Link href="/shop" className="button button-light" onClick={() => setCartOpen(false)}>Continue shopping</Link></div></> : <div className="empty-drawer"><p>Your saved pieces will appear here.</p><Link href="/shop" className="button button-dark" onClick={() => setCartOpen(false)}>Shop the collection</Link></div>}</aside></div> : null;
}

function SearchOverlay() {
  const { searchOpen, setSearchOpen } = useStore(); const [query, setQuery] = useState(""); const results = useMemo(() => { const normalized = query.toLowerCase().trim(); return normalized ? products.filter((p) => [p.name, p.description, p.category, p.gender, p.collection, ...p.tags].join(" ").toLowerCase().includes(normalized)).slice(0, 5) : products.filter((p) => p.featured).slice(0, 4); }, [query]);
  useEffect(() => { if (!searchOpen) setQuery(""); }, [searchOpen]);
  if (!searchOpen) return null;
  return <div className="search-overlay"><div className="search-overlay-top"><Link href="/" className="brand-mark"><span className="monogram">SS</span><span className="wordmark">PASSION</span></Link><button onClick={() => setSearchOpen(false)} aria-label="Close search"><X size={22} strokeWidth={1.5} /></button></div><div className="search-inner"><div className="label-eyebrow">Search SS Passion</div><div className="search-input-row"><Search size={22} strokeWidth={1.5} /><input autoFocus value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search products, collections, journal..." /></div><div className="search-rule" />{results.length ? <div className="search-results"><div className="label-eyebrow">{query ? "Suggested products" : "Explore the edit"}</div>{results.map((product) => <Link key={product.id} href={`/product/${product.slug}`} onClick={() => setSearchOpen(false)} className="search-result"><img src={product.images[0]} alt={product.name} /><span>{product.name}<small>{product.category} · {money(product.price)}</small></span><ArrowRight size={15} strokeWidth={1.5} /></Link>)}</div> : <div className="search-empty"><h3>No results found</h3><p>Try another search.</p></div>}</div></div>;
}

export function SiteFooter() { return <footer className="site-footer"><div className="footer-top"><div><div className="brand-mark footer-brand"><span className="monogram">SS</span><span className="wordmark">PASSION</span></div><p className="footer-tagline">Modern clothing for everyday confidence.</p></div><div className="footer-columns"><div><div className="label-eyebrow">Explore</div><Link href="/shop">Shop all</Link><Link href="/shop?gender=Women">Women</Link><Link href="/shop?gender=Men">Men</Link><Link href="/journal">Journal</Link></div><div><div className="label-eyebrow">About</div><Link href="/about">Our approach</Link><Link href="/contact">Contact</Link><Link href="/contact">Shipping & returns</Link><Link href="/contact">FAQ</Link></div><div><div className="label-eyebrow">Follow</div><a href="#instagram">Instagram</a><a href="#pinterest">Pinterest</a><a href="#tiktok">TikTok</a></div></div></div><div className="footer-bottom"><span>© 2026 SS PASSION</span><span>USD · International</span><span>Privacy · Terms</span></div></footer>; }

export function Newsletter() { const [email, setEmail] = useState(""); const [submitted, setSubmitted] = useState(false); return <section className="newsletter"><div><div className="label-eyebrow">Stay in the know</div><h2>Join the SS PASSION list.</h2><p>First access to new collections, stories and selected offers.</p></div><form onSubmit={(e) => { e.preventDefault(); if (email.includes("@")) setSubmitted(true); }}><input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Your email address" /><button className="button button-dark" type="submit">{submitted ? <><Check size={15} /> Thank you</> : <>Join <ArrowRight size={15} /></>}</button>{submitted && <small>Newsletter connection ready for Klaviyo, Mailchimp or Brevo.</small>}</form></section>; }

export function FilterBar({ count, onFilterClick, sort, setSort }: { count: number; onFilterClick: () => void; sort: string; setSort: (v: string) => void }) { return <div className="filter-bar"><button onClick={onFilterClick}><SlidersHorizontal size={16} strokeWidth={1.5} /> Filter</button><span>{count} pieces</span><label>Sort by <select value={sort} onChange={(e) => setSort(e.target.value)}><option value="recommended">Recommended</option><option value="newest">Newest</option><option value="best">Best selling</option><option value="low">Price low to high</option><option value="high">Price high to low</option></select><ChevronDown size={14} /></label></div>; }

export function FilterPanel({ filters, setFilters, close }: { filters: { gender: string; category: string; color: string }; setFilters: (f: { gender: string; category: string; color: string }) => void; close: () => void }) { const options = { gender: ["All", "Women", "Men"], category: ["All", "T-Shirts", "Shirts", "Polos", "Trousers", "Blazers", "Dresses", "Knitwear", "Overshirts"], color: ["All", "Ivory", "Black", "Stone", "Taupe", "Cream", "Grey", "Navy"] }; return <div className="filter-panel"><div className="filter-panel-head"><div><div className="label-eyebrow">Refine</div><h3>Filter pieces</h3></div><button onClick={close}><X size={20} strokeWidth={1.5} /></button></div>{(Object.keys(options) as Array<keyof typeof options>).map((key) => <div className="filter-group" key={key}><div className="filter-group-title">{key}</div><div className="filter-options">{options[key].map((option) => <button key={option} className={(filters[key] === option || (option === "All" && filters[key] === "")) ? "selected" : ""} onClick={() => setFilters({ ...filters, [key]: option === "All" ? "" : option })}>{option}</button>)}</div></div>)}<button className="button button-dark filter-done" onClick={close}>View results <ArrowRight size={15} /></button></div>; }
