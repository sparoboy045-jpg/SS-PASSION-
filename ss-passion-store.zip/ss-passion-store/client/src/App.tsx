import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import { SiteHeader, StorefrontProvider } from "./components/Storefront";
import Home from "./pages/Home";
import Shop from "./pages/Shop";
import Product from "./pages/Product";
import { About, Contact, Journal } from "./pages/Editorial";
import Account, { Wishlist } from "./pages/Account";
import NotFound from "./pages/NotFound";

function Router() {
  return <Switch>
    <Route path="/" component={Home} />
    <Route path="/shop" component={Shop} />
    <Route path="/product/:slug" component={Product} />
    <Route path="/journal" component={Journal} />
    <Route path="/about" component={About} />
    <Route path="/contact" component={Contact} />
    <Route path="/wishlist" component={Wishlist} />
    <Route path="/account" component={Account} />
    <Route path="/404" component={NotFound} />
    <Route component={NotFound} />
  </Switch>;
}

export default function App() {
  return <ErrorBoundary><ThemeProvider defaultTheme="light"><TooltipProvider><Toaster /><StorefrontProvider><SiteHeader /><Router /></StorefrontProvider></TooltipProvider></ThemeProvider></ErrorBoundary>;
}
